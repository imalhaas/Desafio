import { test, expect } from '@playwright/test';


test('Preenche os campos e clica no botão Start Challenge', async ({ page }) => {
  // Navega até a página do formulário
  await page.goto('http://localhost:5173/'); // Substitua pela URL da sua aplicação

  // Preenche os campos do formulário
  await page.fill('input[type="text"]', 'Lucas');
  await page.fill('input[type="tel"]', '123');
  await page.fill('input[type="email"]', 'lucasdecassia9@hotmail.com');

  // Clica no botão de iniciar o desafio
  await page.click('button:has-text("Start Challenge")');

  // Exemplo: Verificar se o botão está desabilitado após o clique
  await expect(page.locator('button:has-text("Start Challenge")')).toBeDisabled();

});


