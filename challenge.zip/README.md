<img width="1430" alt="1" src="https://github.com/user-attachments/assets/b154fa15-b73d-43e7-8254-b486404ce303">
<img width="1422" alt="2" src="https://github.com/user-attachments/assets/27012d3e-ede9-435d-9273-b027bb1dbe16">
<img width="1426" alt="3" src="https://github.com/user-attachments/assets/7617339c-d9b7-4707-88d5-95fb75e027cc">
<img width="1429" alt="4" src="https://github.com/user-attachments/assets/45c93753-c17a-4be8-b184-9472f9f198b6">
<img width="1425" alt="5" src="https://github.com/user-attachments/assets/810346d7-2f38-4709-9fdb-a73d8b176fbd">
